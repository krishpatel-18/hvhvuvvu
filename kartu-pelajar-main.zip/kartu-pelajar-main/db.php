<?php
$conn = mysqli_connect('localhost', 'fyxhpdmx_versi-2', 'fyxhpdmx_versi-2', 'fyxhpdmx_versi-2');
if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}
?>
